﻿__________________________________________

Unzip destroyer.zip and locate USS Fitzgerald folder,
and copy to FSX/simobjects/airplanes/

   locate the fx_Ship_smoke.fx file within the USS Fitzgerald folder,
and paste to FSX/effects/

a step by step guide for the Novice can be found at...

 ==>  http://www.simviation.com/fsxaircraftinstall.htm

this model is the default FSX AI model made flyable

__________________________________________

DDG-62 U.S.S. Fitzgerald

FEATURES:
- Crisp,FPS friendly textures
- Very Stable with no "popping" at all speeds
- Hard deck for VTOL Ops

made pilotable for FSX ONLY by Bruce Fitzgerald
- fitzgeba@hotmail.com
