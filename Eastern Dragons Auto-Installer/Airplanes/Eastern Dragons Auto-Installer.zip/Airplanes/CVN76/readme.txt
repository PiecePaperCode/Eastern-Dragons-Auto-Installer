﻿Unzip CVN76.zip and locate the CVN76 folder
.. and copy to the FSX/simobjects/airplanes folder

locate the effects folder within the CVN76 folder
.. and copy the effects files inside it , 
...and paste to the FSX/effects folder

a complete install tutorial for the novice may be found at
 ==>  http://www.simviation.com/fsxaircraftinstall.htm

this works fine on my system , your system is probably different ...

--------------------------------------------------

CVN-76 USS Ronald Reagan

this is the Acceleration AI Carrier made flyable. 
I got tired of all the bouncy , jumpy MP carriers out there, throwing me off the deck.
so i present you this Ultra stable Carrier Op's platform

Features:

- Rock solid flight deck , No bouncing, tilting ... nuttin'
- "pri-fly" view to watch all the action on deck
- ATC equiped bridge
- 40kts top speed
- cables work in MP
- CVN-76 details and crisp DXT textures

made flyable for FSX Only by Bruce Fitzgerald / fitzgeba@hotmail.com