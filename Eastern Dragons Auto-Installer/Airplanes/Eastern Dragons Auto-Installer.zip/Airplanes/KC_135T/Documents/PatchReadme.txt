
		KC-135T v1.9 Patch

This is a patch for "KC-135T v1.85 for FS2002/2004", filename "kc-135t1.zip". This installer presumes you have it installed in "...Aircraft\KC-135T" folder. If you installed the original package in different folder, you will have to overwrite old files manually.

		INSTALLATION

When prompted, select you Flight Simulator (2002 or 2004) installation directory.

IMPORTANT!

This patch automatically overwrites old files from our original package. If you made any changes or modifications to them, be shure to make a backup NOW!

		PATCH CHANGES

-models with fixed refueling boom and drogue attached added
-refueling boom is now fully animated
-refueling boom animateion key changed from Concorde Visor to Tailhook (you must now use Tailhook command to operate the boom, see Documents folder for more info)
-some texture improvements, including better engine textures and yellow guide line
-sample AI flights (for FS2004) added, see Traffic folder
-all Glass Cockpit
-new gauges added